import { createApp } from 'vue'
// import { createApp } from '../node_modules/vue';
import App from './App.vue'

createApp(App).mount('#app')




// function count (elements) {
//     return ...elements
// }

// function show () {
//     print count([1,2,3,4]);
// }

// x = require (../secondFile);

// x.count()
// //////////////////////////
// class Dog {
//     function woof() {...}

//     function walk () {...}
// }

// var chichuahua = new Dog();
// var shepherd = new Dog();

// chichuahua.woof();
// shepherd.woof();

// class SmallDog extends Dog {
//     function bite () {...}
// }

// var chichuahua = new SmallDog();
// chichuahua.bite();
// chichuahua.walk();
// chichuahua.woof();